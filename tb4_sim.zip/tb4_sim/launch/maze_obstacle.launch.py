"""Place the same static detection objects in every maze session."""

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.substitutions import PathJoinSubstitution
from launch_ros.actions import Node


def generate_launch_description():
    project_share = get_package_share_directory('tb4_sim')
    # Entity name, SDF model, map x, map y, yaw (radians).
    # Keep furniture in clusters and leave the passages and route goals free.
    objects = [
        ('table', 'maze_table', '-3.0', '5.0', '0.0'),
        ('chair_south', 'maze_chair', '-3.0', '4.1', '3.14159'),
        ('chair_north', 'maze_chair', '-3.0', '5.9', '0.0'),
        ('rug', 'maze_rug', '-3.0', '5.0', '0.0'),
        ('bench', 'maze_bench', '-3.0', '1.0', '0.0'),
        ('plant_by_bench', 'maze_potted_plant', '-2.0', '1.0', '0.0'),
        ('plant_west', 'maze_potted_plant', '-7.0', '-1.0', '0.0'),
        ('plant_northwest', 'maze_potted_plant', '-8.0', '8.0', '0.0'),
        ('plant_southwest', 'maze_potted_plant', '-8.0', '-5.0', '0.0'),
        ('person', 'maze_person', '-6.0', '-3.0', '0.0'),
        ('suitcase_by_person', 'maze_suitcase', '-5.3', '-3.2', '0.0'),
        ('fire_extinguisher', 'maze_fire_extinguisher', '5.0', '-3.0', '0.0'),
        ('barrel', 'maze_barrel', '7.0', '-3.0', '0.0'),
    ]
    spawns = []
    for entity_name, model_name, x, y, yaw in objects:
        model_sdf = PathJoinSubstitution([project_share, 'models', f'{model_name}.sdf'])
        spawns.append(Node(
            package='ros_ign_gazebo',
            executable='create',
            name=f'spawn_{entity_name}',
            output='screen',
            arguments=[
                '-world', 'maze',
                '-file', model_sdf,
                '-name', entity_name,
                '-x', x, '-y', y, '-z', '0.0', '-Y', yaw,
            ],
        ))
    return LaunchDescription(spawns)
