from ament_index_python.packages import get_package_share_directory

from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    ExecuteProcess,
    IncludeLaunchDescription,
    SetEnvironmentVariable,
    TimerAction,
)
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution, PythonExpression
from launch_ros.actions import Node


def generate_launch_description():
    bringup_share = get_package_share_directory('turtlebot4_ignition_bringup')
    navigation_share = get_package_share_directory('turtlebot4_navigation')
    project_share = get_package_share_directory('tb4_sim')
    obstacle_launch = PathJoinSubstitution([
        project_share, 'launch', 'maze_obstacle.launch.py'
    ])
    ignition_launch = PathJoinSubstitution([
        bringup_share, 'launch', 'ignition.launch.py'
    ])
    robot_launch = PathJoinSubstitution([
        bringup_share, 'launch', 'turtlebot4_spawn.launch.py'
    ])
    localization_launch = PathJoinSubstitution([
        navigation_share, 'launch', 'localization.launch.py'
    ])
    localization_params = PathJoinSubstitution([
        project_share, 'config', 'localization.yaml'
    ])
    nav2_launch = PathJoinSubstitution([
        navigation_share, 'launch', 'nav2.launch.py'
    ])
    rviz_config = PathJoinSubstitution([
        project_share, 'rviz', 'navigation_yolo.rviz'
    ])
    nav2_params = PathJoinSubstitution([
        project_share, 'config', 'nav2_keepout.yaml'
    ])
    keepout_mask = PathJoinSubstitution([
        project_share, 'maps', 'bench_keepout.yaml'
    ])
    keepout_server_params = PathJoinSubstitution([
        project_share, 'config', 'keepout_filter.yaml'
    ])

    args = [
        DeclareLaunchArgument('world', default_value='maze'),
        DeclareLaunchArgument('maze_obstacle', default_value='true',
                              choices=['true', 'false']),
        DeclareLaunchArgument('model', default_value='standard'),
        DeclareLaunchArgument(
            'map',
            default_value='/home/vtd/ros2_ws/src/tb4_sim/maps/map_new.yaml',
            description='Full path to the map YAML saved after SLAM'),
        DeclareLaunchArgument('x', default_value='0.0'),
        DeclareLaunchArgument('y', default_value='0.0'),
        DeclareLaunchArgument('z', default_value='0.0'),
        DeclareLaunchArgument('yaw', default_value='0.0'),
    ]

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(ignition_launch),
        launch_arguments={
            'world': LaunchConfiguration('world'),
            'model': LaunchConfiguration('model'),
        }.items(),
    )
    obstacle = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(obstacle_launch),
        condition=IfCondition(PythonExpression([
            "'", LaunchConfiguration('world'), "' == 'maze' and '",
            LaunchConfiguration('maze_obstacle'), "' == 'true'",
        ])),
    )
    robot = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(robot_launch),
        launch_arguments={
            'model': LaunchConfiguration('model'),
            'rviz': 'false',
            'use_sim_time': 'true',
            'localization': 'false',
            'slam': 'false',
            'nav2': 'false',
            'x': LaunchConfiguration('x'),
            'y': LaunchConfiguration('y'),
            'z': LaunchConfiguration('z'),
            'yaw': LaunchConfiguration('yaw'),
        }.items(),
    )
    localization = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(localization_launch),
        launch_arguments={
            'map': LaunchConfiguration('map'),
            'params': localization_params,
            'use_sim_time': 'true',
        }.items(),
    )
    navigation = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(nav2_launch),
        launch_arguments={
            'use_sim_time': 'true',
            'params_file': nav2_params,
        }.items(),
    )
    keepout_mask_server = Node(
        package='nav2_map_server',
        executable='map_server',
        name='bench_keepout_mask_server',
        output='screen',
        parameters=[
            keepout_server_params,
            {'yaml_filename': keepout_mask},
        ],
    )
    keepout_info_server = Node(
        package='nav2_map_server',
        executable='costmap_filter_info_server',
        name='bench_keepout_info_server',
        output='screen',
        parameters=[keepout_server_params],
    )
    keepout_lifecycle = Node(
        package='nav2_lifecycle_manager',
        executable='lifecycle_manager',
        name='lifecycle_manager_bench_keepout',
        output='screen',
        parameters=[{
            'use_sim_time': True,
            'autostart': True,
            'node_names': [
                'bench_keepout_mask_server',
                'bench_keepout_info_server',
            ],
        }],
    )
    rviz = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        arguments=['-d', rviz_config],
        parameters=[{'use_sim_time': True}],
        output='screen',
    )

    # In simulation, let Create 3's automatic recovery back up far enough to
    # clear a hazard. Keep cliff protection and the normal speed cap enabled.
    set_backup_only_safety = TimerAction(
        period=15.0,
        actions=[ExecuteProcess(
            cmd=[
                'bash', '-lc',
                'until ros2 param set /motion_control safety_override '
                'backup_only; do sleep 2; done',
            ],
            output='screen',
        )],
    )

    return LaunchDescription([
        SetEnvironmentVariable('ROS_DOMAIN_ID', '24'),
        *args,
        gazebo,
        obstacle,
        robot,
        localization,
        keepout_mask_server,
        keepout_info_server,
        keepout_lifecycle,
        navigation,
        rviz,
        set_backup_only_safety,
    ])
