"""Navigate through three map poses in order with Nav2."""

import math
import time

import rclpy
from geometry_msgs.msg import PoseStamped
from nav2_simple_commander.robot_navigator import TaskResult
from turtlebot4_navigation.turtlebot4_navigator import TurtleBot4Navigator


def goal_pose(navigator, x, y, yaw):
    pose = PoseStamped()
    pose.header.frame_id = 'map'
    pose.header.stamp = navigator.get_clock().now().to_msg()
    pose.pose.position.x = x
    pose.pose.position.y = y
    pose.pose.orientation.z = math.sin(yaw / 2.0)
    pose.pose.orientation.w = math.cos(yaw / 2.0)
    return pose


def main(args=None):
    rclpy.init(args=args)
    navigator = TurtleBot4Navigator()
    active_goal = False
    try:
        navigator.declare_parameter('auto_undock', True)
        navigator.declare_parameter('goal_count', 4)
        goal_count = int(navigator.get_parameter('goal_count').value)
        if goal_count < 1:
            raise ValueError('goal_count must be at least 1')
        navigator.declare_parameter('use_staging_pose', False)
        staging_values = []
        for axis in ('x', 'y', 'yaw'):
            name = f'staging_{axis}'
            navigator.declare_parameter(name, 0.0)
            value = float(navigator.get_parameter(name).value)
            if not math.isfinite(value):
                raise ValueError(f'{name} must be finite')
            staging_values.append(value)
        goals = []
        for index in range(1, goal_count + 1):
            values = []
            for axis in ('x', 'y', 'yaw'):
                name = f'goal{index}_{axis}'
                navigator.declare_parameter(name, 0.0)
                value = float(navigator.get_parameter(name).value)
                if not math.isfinite(value):
                    raise ValueError(f'{name} must be finite')
                values.append(value)
            goals.append(values)

        # BasicNavigator otherwise publishes its default (0, 0, 0) initial pose.
        # Keep the pose already established by localization.yaml or RViz.
        navigator.get_logger().info('Waiting for AMCL pose before starting Nav2')
        deadline = time.monotonic() + 60.0
        while rclpy.ok() and not navigator.initial_pose_received:
            if time.monotonic() >= deadline:
                raise TimeoutError('No /amcl_pose received within 60 seconds')
            rclpy.spin_once(navigator, timeout_sec=0.5)
        navigator.get_logger().info('Waiting for AMCL and Nav2 to become active')
        navigator.waitUntilNav2Active()
        if navigator.get_parameter('auto_undock').value and navigator.getDockedStatus():
            navigator.undock()
            if navigator.getDockedStatus():
                raise RuntimeError('Robot is still docked after undock action')

        if navigator.get_parameter('use_staging_pose').value:
            x, y, yaw = staging_values
            pose = goal_pose(navigator, x, y, yaw)
            navigator.get_logger().info(
                f'Navigating to staging pose: x={x:.2f}, y={y:.2f}, yaw={yaw:.2f} rad')
            if not navigator.goToPose(pose):
                raise RuntimeError('Staging pose was rejected')
            active_goal = True
            while not navigator.isTaskComplete():
                time.sleep(0.05)
            active_goal = False
            result = navigator.getResult()
            if result != TaskResult.SUCCEEDED:
                raise RuntimeError(f'Staging pose ended with {result.name}')
            navigator.get_logger().info('Staging pose reached')

        for index, (x, y, yaw) in enumerate(goals, start=1):
            pose = goal_pose(navigator, x, y, yaw)
            navigator.get_logger().info(
                f'Goal {index}/{len(goals)}: x={x:.2f}, y={y:.2f}, yaw={yaw:.2f} rad')
            if not navigator.goToPose(pose):
                raise RuntimeError(f'Goal {index} was rejected')
            active_goal = True
            while not navigator.isTaskComplete():
                time.sleep(0.05)
            active_goal = False
            result = navigator.getResult()
            if result != TaskResult.SUCCEEDED:
                raise RuntimeError(f'Goal {index} ended with {result.name}')
            navigator.get_logger().info(f'Goal {index} reached')
        navigator.get_logger().info(f'All {len(goals)} goals reached in order')
    except KeyboardInterrupt:
        if active_goal:
            navigator.cancelTask()
    except Exception as exc:
        if active_goal:
            navigator.cancelTask()
        navigator.get_logger().error(str(exc))
        raise
    finally:
        navigator.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
