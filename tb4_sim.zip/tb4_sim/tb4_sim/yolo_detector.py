"""Detect objects in TurtleBot 4 RGB images and publish annotated frames."""

import threading
import time

import cv2
import numpy as np
from cv_bridge import CvBridge
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
import rclpy
from sensor_msgs.msg import Image


class YoloDetector(Node):
    def __init__(self):
        super().__init__('yolo_detector')
        self.declare_parameter('image_topic', '/oakd/rgb/preview/image_raw')
        self.declare_parameter('annotated_topic', '/yolo/annotated_image')
        self.declare_parameter('model_path', 'yolov8s-world.pt')
        self.declare_parameter('confidence', 0.03)
        # Descriptive prompts work better than bare nouns on low-poly Gazebo assets.
        self.declare_parameter(
            'class_allowlist', [
                'a potted tree with green leaves',
                'a wooden table',
                'a wooden chair with a backrest',
                'a long wooden bench with a backrest',
                'a person',
                'a dark blue suitcase',
                'a blue metal barrel drum',
                'a red cylinder'])
        self.declare_parameter('period', 0.5)
        self.declare_parameter('image_size', 960)

        self.bridge = CvBridge()
        self.latest_image = None
        self.detections = ()
        self.has_inference = False
        self.last_seen_class = {}
        self.lock = threading.Lock()
        self.stop_worker = threading.Event()
        confidence = float(self.get_parameter('confidence').value)
        period = float(self.get_parameter('period').value)
        self.image_size = int(self.get_parameter('image_size').value)
        if not 0.0 < confidence <= 1.0 or period <= 0.0 or self.image_size <= 0:
            raise ValueError('confidence and period must be positive; image_size must be positive')
        self.confidence = confidence
        self.period = period
        self.class_allowlist = {
            str(name).strip().lower()
            for name in self.get_parameter('class_allowlist').value
            if str(name).strip()
        }

        model_path = str(self.get_parameter('model_path').value)
        if 'world' in model_path.lower():
            from ultralytics import YOLOWorld
            self.model = YOLOWorld(model_path)
            self.model.set_classes(sorted(self.class_allowlist))
        else:
            from ultralytics import YOLO
            self.model = YOLO(model_path)
        image_topic = self.get_parameter('image_topic').value
        annotated_topic = self.get_parameter('annotated_topic').value
        self.create_subscription(Image, image_topic, self.on_image, qos_profile_sensor_data)
        self.publisher = self.create_publisher(Image, annotated_topic, 10)
        self.worker = threading.Thread(target=self.inference_loop, daemon=True)
        self.worker.start()
        classes = ', '.join(sorted(self.class_allowlist)) or 'all model classes'
        self.get_logger().info(
            f'Loaded {model_path}; classes: {classes}; confidence: {self.confidence:.2f}; '
            f'image size: {self.image_size}')
        self.get_logger().info(
            f'YOLO listening to {image_topic}; publishing {annotated_topic}')

    def on_image(self, msg):
        with self.lock:
            self.latest_image = msg
            detections = self.detections
            has_inference = self.has_inference
        try:
            frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
            for x1, y1, x2, y2, label in detections:
                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 220, 0), 2)
                text_size, baseline = cv2.getTextSize(
                    label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
                text_y = max(y1, text_size[1] + 4)
                cv2.rectangle(
                    frame,
                    (x1, text_y - text_size[1] - 4),
                    (x1 + text_size[0] + 4, text_y + baseline),
                    (0, 150, 0), -1)
                cv2.putText(
                    frame, label, (x1 + 2, text_y - 2),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1,
                    cv2.LINE_AA)
            status = (
                'YOLO: ' + ', '.join(label.rsplit(' ', 1)[0] for *_, label in detections)
                if detections else (
                    'YOLO: no target class detected'
                    if has_inference else 'YOLO: waiting for first inference'))
            cv2.putText(
                frame, status, (10, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.55,
                (0, 255, 255), 2, cv2.LINE_AA)
            annotated = self.bridge.cv2_to_imgmsg(frame, encoding='bgr8')
            annotated.header = msg.header
            self.publisher.publish(annotated)
        except Exception as exc:
            self.get_logger().error(f'Image processing failed: {exc}')

    def inference_loop(self):
        while not self.stop_worker.is_set():
            with self.lock:
                msg = self.latest_image
                self.latest_image = None
            if msg is None:
                self.stop_worker.wait(0.05)
                continue

            started = time.monotonic()
            try:
                frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
                result = self.model.predict(
                    frame,
                    conf=self.confidence,
                    imgsz=self.image_size,
                    verbose=False,
                )[0]
                detections = []
                for box in result.boxes:
                    class_id = int(box.cls.item())
                    score = float(box.conf.item())
                    class_name = str(result.names[class_id]).lower()
                    if self.class_allowlist and class_name not in self.class_allowlist:
                        continue
                    x1, y1, x2, y2 = (int(value) for value in box.xyxy[0].tolist())
                    display_name = {
                        'a potted tree with green leaves': 'tree',
                        'a wooden table': 'table',
                        'a wooden chair with a backrest': 'chair',
                        'a long wooden bench with a backrest': 'bench',
                        'a person': 'person',
                        'a dark blue suitcase': 'suitcase',
                        'a blue metal barrel drum': 'barrel',
                        'a red cylinder': 'fire extinguisher',
                    }.get(class_name, class_name)
                    label = f'{display_name} {score:.2f}'
                    detections.append((x1, y1, x2, y2, label))
                for x1, y1, x2, y2, label in self.sim_asset_detections(frame, detections):
                    detections.append((x1, y1, x2, y2, label))

                # Report a class once while it remains visible. Inference runs
                # repeatedly on video frames, so logging every frame made one
                # stationary object look like many separate detections.
                now = time.monotonic()
                current_classes = {}
                for *_, label in detections:
                    clean_label = label.split(' (Gazebo asset', 1)[0]
                    clean_label = clean_label.split(' [', 1)[0]
                    parts = clean_label.rsplit(' ', 1)
                    if len(parts) == 2:
                        try:
                            float(parts[1])
                            clean_label = parts[0]
                        except ValueError:
                            pass
                    current_classes.setdefault(clean_label, label)
                for class_name, label in current_classes.items():
                    if class_name not in self.last_seen_class:
                        self.get_logger().info(f'Detected {label}')
                    self.last_seen_class[class_name] = now
                self.last_seen_class = {
                    name: seen_at for name, seen_at in self.last_seen_class.items()
                    if now - seen_at <= 3.0 or name in current_classes
                }
                with self.lock:
                    self.detections = tuple(detections)
                    self.has_inference = True
            except Exception as exc:
                self.get_logger().error(f'YOLO inference failed: {exc}')

            remaining = self.period - (time.monotonic() - started)
            if remaining > 0.0:
                self.stop_worker.wait(remaining)

    @staticmethod
    def sim_asset_detections(frame, yolo_detections):
        """Fallback for the distinctive low-poly assets shipped with this maze."""
        height, width = frame.shape[:2]
        image_area = height * width
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        occupied = {label.rsplit(' ', 1)[0] for *_, label in yolo_detections}
        found = []

        def components(mask, min_area):
            mask = cv2.morphologyEx(
                mask.astype(np.uint8), cv2.MORPH_CLOSE,
                np.ones((3, 3), np.uint8))
            count, _, stats, _ = cv2.connectedComponentsWithStats(mask, 8)
            return [tuple(int(v) for v in stats[i, :5]) for i in range(1, count)
                    if stats[i, cv2.CC_STAT_AREA] >= min_area]

        # maze_suitcase.sdf is a compact, brighter blue object. Maze walls are
        # much larger teal/navy regions, so reject broad components and use a
        # narrower blue hue/saturation/value range than the old wall-prone mask.
        if 'suitcase' not in occupied:
            mask = ((hsv[:, :, 0] >= 108) & (hsv[:, :, 0] <= 122) &
                    (hsv[:, :, 1] >= 85) & (hsv[:, :, 2] >= 45) &
                    (hsv[:, :, 2] <= 115))
            for x, y, w, h, area in components(mask, max(120, int(image_area * 0.002))):
                aspect = h / max(w, 1)
                # Walls can satisfy the blue-color test over a huge region;
                # the suitcase is a bounded upright object in this camera view.
                if (area <= image_area * 0.10 and w * h <= image_area * 0.12 and
                        0.65 <= aspect <= 2.5 and w >= width * 0.06 and
                        h >= height * 0.10):
                    found.append((x, y, x + w, y + h, 'suitcase'))
                    break

        # The maze drum has a saturated blue-teal body, dark gray rim/band,
        # and a compact upright silhouette. Close the thin dark band so the
        # two visible sections form one candidate; broad wall regions are
        # excluded by the component and bounding-box size limits.
        if 'barrel' not in occupied:
            barrel_mask = ((hsv[:, :, 0] >= 94) & (hsv[:, :, 0] <= 108) &
                           (hsv[:, :, 1] >= 75) & (hsv[:, :, 2] >= 35) &
                           (hsv[:, :, 2] <= 190)).astype(np.uint8)
            barrel_mask = cv2.morphologyEx(
                barrel_mask, cv2.MORPH_CLOSE, np.ones((15, 5), np.uint8))
            for x, y, w, h, area in components(
                    barrel_mask, max(100, int(image_area * 0.0015))):
                aspect = h / max(w, 1)
                if (area <= image_area * 0.10 and w * h <= image_area * 0.12 and
                        0.9 <= aspect <= 2.8 and w >= width * 0.055 and
                        h >= height * 0.08):
                    found.append((x, y, x + w, y + h, 'barrel'))
                    break

        # The fire extinguisher SDF is the only saturated red upright object.
        if 'fire extinguisher' not in occupied:
            red = (((hsv[:, :, 0] <= 9) | (hsv[:, :, 0] >= 170)) &
                   (hsv[:, :, 1] >= 100) & (hsv[:, :, 2] >= 35))
            for x, y, w, h, area in components(red, max(100, int(image_area * 0.001))):
                if h >= w * 1.25 and h >= height * 0.10:
                    pad_x, pad_y = max(2, w // 8), max(2, h // 8)
                    found.append((max(0, x - pad_x), max(0, y - pad_y),
                                  min(width, x + w + pad_x), min(height, y + h + pad_y),
                                  'fire extinguisher [color]'))
                    break

        # The mannequin's blue torso is brighter than the dark maze walls and suitcase.
        if 'person' not in occupied:
            blue = ((hsv[:, :, 0] >= 100) & (hsv[:, :, 0] <= 130) &
                    (hsv[:, :, 1] >= 80) & (hsv[:, :, 2] >= 90))
            for x, y, w, h, area in components(blue, max(80, int(image_area * 0.0007))):
                if any(label == 'barrel' and x < bx2 and x + w > bx1 and
                       y < by2 and y + h > by1
                       for bx1, by1, bx2, by2, label in found):
                    continue
                aspect = w / max(h, 1)
                if 0.35 <= aspect <= 2.2 and h >= height * 0.035:
                    # Expand the torso box to include the mannequin's head and legs.
                    top = max(0, y - int(h * 0.8))
                    bottom = min(height, y + int(h * 2.2))
                    pad = max(2, int(w * 0.45))
                    found.append((max(0, x - pad), top, min(width, x + w + pad), bottom,
                                  'person'))
                    break

        # Brown SDF furniture: the maze bench is much longer than its depth,
        # while chair backs are tall. Large floor rugs are excluded.
        if 'table' not in occupied or 'chair' not in occupied or 'bench' not in occupied:
            green = ((hsv[:, :, 0] >= 35) & (hsv[:, :, 0] <= 90) &
                     (hsv[:, :, 1] >= 100) & (hsv[:, :, 2] >= 40))
            plant_regions = []
            for gx, gy, gw, gh, _ in components(
                    green, max(40, int(image_area * 0.0005))):
                plant_regions.append((gx - gw, gy + gh - 3,
                                      gx + 2 * gw, gy + gh + 2 * gh))
            wood = ((hsv[:, :, 0] >= 5) & (hsv[:, :, 0] <= 24) &
                    (hsv[:, :, 1] >= 75) & (hsv[:, :, 2] >= 30) &
                    (hsv[:, :, 2] <= 190))
            table_added = 'table' in occupied
            chair_added = 'chair' in occupied
            bench_added = 'bench' in occupied
            for x, y, w, h, area in sorted(
                    components(wood, max(100, int(image_area * 0.001))),
                    key=lambda item: item[4], reverse=True):
                if area > image_area * 0.15:
                    continue
                if any(x < rx2 and x + w > rx1 and y < ry2 and y + h > ry1
                       for rx1, ry1, rx2, ry2 in plant_regions):
                    continue
                ratio = w / max(h, 1)
                if (not bench_added and w >= width * 0.12 and ratio >= 2.15):
                    found.append((x, y, x + w, y + h, 'bench'))
                    bench_added = True
                elif not table_added and w >= width * 0.09 and ratio >= 2.2:
                    found.append((x, y, x + w, y + h, 'table'))
                    table_added = True
                elif (not chair_added and h >= height * 0.06 and
                      h / max(w, 1) >= 1.25 and w >= width * 0.025):
                    found.append((x, y, x + w, y + h, 'chair'))
                    chair_added = True
                if table_added and chair_added and bench_added:
                    break
        return found

    def destroy_node(self):
        self.stop_worker.set()
        if self.worker.is_alive():
            self.worker.join(timeout=2.0)
        return super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = None
    try:
        node = YoloDetector()
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if node is not None:
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
